/* Landing page interactions */
document.addEventListener('DOMContentLoaded', () => {
  initRevealOnScroll();

  const modal = document.getElementById('investorModal');
  const openModal = () => modal.classList.add('open');
  const closeModal = () => modal.classList.remove('open');

  document.getElementById('investorDemoBtn')?.addEventListener('click', openModal);
  document.getElementById('modalClose')?.addEventListener('click', closeModal);
  modal?.addEventListener('click', (e)=>{ if(e.target===modal) closeModal(); });
  document.getElementById('enterDashboardBtn')?.addEventListener('click', () => location.href = 'dashboard.html');

  ['viewDemoBtn','viewDemoBtn2','viewDemoBtn3'].forEach(id=>{
    document.getElementById(id)?.addEventListener('click', ()=> location.href = 'dashboard.html');
  });
  ['joinWaitlistBtn','joinWaitlistBtn2'].forEach(id=>{
    document.getElementById(id)?.addEventListener('click', ()=> location.href = 'login.html');
  });

  const navToggle = document.getElementById('navToggle');
  navToggle?.addEventListener('click', () => {
    const links = document.querySelector('.nav-links');
    links.style.display = links.style.display === 'flex' ? 'none' : 'flex';
    links.style.flexDirection = 'column';
    links.style.position='absolute';
    links.style.top='76px';
    links.style.left='0';
    links.style.right='0';
    links.style.background='var(--card)';
    links.style.padding='20px 28px';
    links.style.borderBottom='1px solid var(--border)';
  });
});
