const JeevaniData = (() => {

  const DEFAULTS = {
    user: { name: "Ananya Sharma", phone: "+91 98765 43210", city: "Delhi" },

    family: [
      { id:"f1", name:"Rajesh Sharma", role:"Father", age:58, blood:"B+", score:71, lastCheckup:"2026-03-12", avatar:"👨🏽", conditions:["Hypertension","Type-2 Diabetes"] },
      { id:"f2", name:"Sunita Sharma", role:"Mother", age:54, blood:"O+", score:79, lastCheckup:"2025-07-02", avatar:"👩🏽", conditions:["Thyroid (Hypothyroid)"] },
      { id:"f3", name:"Ananya Sharma", role:"Daughter", age:24, blood:"B+", score:91, lastCheckup:"2026-05-20", avatar:"👧🏽", conditions:[] },
      { id:"f4", name:"Aarav Sharma", role:"Son", age:16, blood:"O+", score:88, lastCheckup:"2026-01-15", avatar:"🧑🏽", conditions:["Mild Asthma"] },
    ],

    records: [
      { id:"r1", name:"Complete Blood Count (CBC)", category:"Blood Tests", member:"Rajesh Sharma", doctor:"Dr. Meera Iyer", date:"2026-05-02", type:"PDF", size:"1.2 MB" },
      { id:"r2", name:"HbA1c & Lipid Profile", category:"Blood Tests", member:"Rajesh Sharma", doctor:"Dr. Meera Iyer", date:"2026-04-01", type:"PDF", size:"0.9 MB" },
      { id:"r3", name:"Amlodipine 5mg Prescription", category:"Prescriptions", member:"Rajesh Sharma", doctor:"Dr. Vikram Nair", date:"2026-03-12", type:"PDF", size:"210 KB" },
      { id:"r4", name:"Chest X-Ray Report", category:"X-Rays", member:"Aarav Sharma", doctor:"Dr. Kavita Rao", date:"2026-02-18", type:"DICOM", size:"6.4 MB" },
      { id:"r5", name:"Star Health Policy Renewal", category:"Insurance", member:"Family", doctor:"—", date:"2026-01-05", type:"PDF", size:"2.1 MB" },
      { id:"r6", name:"Thyroid Profile (TSH, T3, T4)", category:"Blood Tests", member:"Sunita Sharma", doctor:"Dr. Meera Iyer", date:"2026-04-22", type:"PDF", size:"0.7 MB" },
      { id:"r7", name:"Tetanus Booster Record", category:"Vaccinations", member:"Aarav Sharma", doctor:"Dr. Kavita Rao", date:"2025-11-10", type:"JPG", size:"480 KB" },
      { id:"r8", name:"Annual Health Checkup Summary", category:"Health Checkups", member:"Ananya Sharma", doctor:"Dr. Priya Das", date:"2026-05-20", type:"PDF", size:"1.5 MB" },
      { id:"r9", name:"Metformin 500mg Prescription", category:"Prescriptions", member:"Rajesh Sharma", doctor:"Dr. Vikram Nair", date:"2026-03-12", type:"PDF", size:"195 KB" },
      { id:"r10", name:"Calcium + Vitamin D3 Prescription", category:"Prescriptions", member:"Sunita Sharma", doctor:"Dr. Meera Iyer", date:"2026-02-02", type:"PDF", size:"180 KB" },
      { id:"r11", name:"COVID-19 Vaccination Certificate", category:"Vaccinations", member:"Family", doctor:"Govt. of India", date:"2025-09-19", type:"PDF", size:"310 KB" },
      { id:"r12", name:"Knee MRI Scan", category:"X-Rays", member:"Sunita Sharma", doctor:"Dr. Kavita Rao", date:"2025-12-08", type:"DICOM", size:"8.1 MB" },
    ],

    reminders: [
      { id:"m1", member:"Rajesh Sharma", medicine:"Amlodipine 5mg", time:"08:00", status:"taken", dose:"1 tablet" },
      { id:"m2", member:"Rajesh Sharma", medicine:"Metformin 500mg", time:"14:00", status:"pending", dose:"1 tablet, after food" },
      { id:"m3", member:"Rajesh Sharma", medicine:"Atorvastatin 10mg", time:"21:00", status:"pending", dose:"1 tablet" },
      { id:"m4", member:"Sunita Sharma", medicine:"Calcium + D3", time:"09:00", status:"taken", dose:"1 tablet" },
      { id:"m5", member:"Sunita Sharma", medicine:"Thyronorm 50mcg", time:"06:30", status:"missed", dose:"1 tablet, empty stomach" },
      { id:"m6", member:"Aarav Sharma", medicine:"Montair LC", time:"21:30", status:"pending", dose:"1 tablet" },
    ],

    adherence: [88, 92, 76, 95, 81, 70, 90],

    timeline: [
      { date:"2026-06-15", type:"Doctor Visit", member:"Rajesh Sharma", title:"Cardiology follow-up", detail:"Routine BP check with Dr. Vikram Nair — stable readings, dosage unchanged." },
      { date:"2026-06-02", type:"Medicine Started", member:"Aarav Sharma", title:"Started Montair LC", detail:"Prescribed for seasonal asthma flare-up." },
      { date:"2026-05-20", type:"Health Checkup", member:"Ananya Sharma", title:"Annual wellness checkup completed", detail:"All vitals normal. Next checkup due May 2027." },
      { date:"2026-05-02", type:"Blood Test Uploaded", member:"Rajesh Sharma", title:"CBC report uploaded", detail:"Uploaded by Ananya via mobile scan." },
      { date:"2026-04-22", type:"Blood Test Uploaded", member:"Sunita Sharma", title:"Thyroid profile uploaded", detail:"TSH slightly elevated — flagged for review." },
      { date:"2026-04-01", type:"Blood Test Uploaded", member:"Rajesh Sharma", title:"HbA1c & Lipid profile uploaded", detail:"HbA1c trending upward over 3 reports." },
      { date:"2026-03-12", type:"Doctor Visit", member:"Rajesh Sharma", title:"Diabetes & BP review", detail:"Dosage adjusted, new prescriptions added." },
      { date:"2026-02-18", type:"X-Ray", member:"Aarav Sharma", title:"Chest X-ray taken", detail:"Routine check after persistent cough — clear results." },
      { date:"2026-01-05", type:"Insurance Renewed", member:"Family", title:"Star Health policy renewed", detail:"Family floater plan renewed for ₹10L cover." },
      { date:"2025-12-08", type:"X-Ray", member:"Sunita Sharma", title:"Knee MRI scan", detail:"Mild wear noted, physiotherapy recommended." },
      { date:"2025-11-10", type:"Vaccination Completed", member:"Aarav Sharma", title:"Tetanus booster given", detail:"Administered at school health camp." },
      { date:"2025-09-19", type:"Vaccination Completed", member:"Family", title:"COVID-19 booster doses", detail:"All family members vaccinated." },
    ],

    insights: [
      { id:"i1", member:"Rajesh Sharma", severity:"high", title:"Rising blood sugar trend detected", body:"Father's HbA1c has increased across the last three uploaded reports — from 6.4% to 7.1% to 7.6%.", rec:"Schedule a physician consultation within 2 weeks." },
      { id:"i2", member:"Sunita Sharma", severity:"medium", title:"Annual screening overdue", body:"Mother has not completed a full health screening in 11 months.", rec:"Book an annual wellness checkup this month." },
      { id:"i3", member:"Family", severity:"medium", title:"Medicine adherence dropping", body:"Family-wide medicine adherence dropped by 12% this month, mostly evening doses.", rec:"Enable advanced reminders with escalation alerts." },
      { id:"i4", member:"Aarav Sharma", severity:"low", title:"Asthma symptom pattern", body:"Mild asthma flare-ups correlate with seasonal pollen spikes in the last 2 years.", rec:"Pre-emptively renew inhaler stock each March." },
      { id:"i5", member:"Sunita Sharma", severity:"low", title:"Thyroid levels borderline", body:"TSH levels are at the upper edge of normal range in the latest report.", rec:"Re-test in 3 months to confirm trend." },
    ],

    emergencyContacts: [
      { name:"Dr. Vikram Nair", role:"Family Physician (Cardiology)", phone:"+91 98110 22334" },
      { name:"Dr. Meera Iyer", role:"Pathology / Diagnostics", phone:"+91 98220 11445" },
      { name:"Apollo Hospital, Delhi", role:"Preferred Hospital", phone:"+91 11 2692 5858" },
      { name:"Star Health Insurance", role:"Insurance Helpline", phone:"1800 425 2255" },
    ],

    hospitals: [
      { name:"Apollo Hospital, Sarita Vihar", distance:"3.2 km", eta:"11 min" },
      { name:"Max Super Speciality, Saket", distance:"5.8 km", eta:"17 min" },
      { name:"AIIMS, New Delhi", distance:"8.1 km", eta:"24 min" },
    ],

    notifications: [
      { ic:"💊", color:"success", title:"Reminder: Metformin 500mg", sub:"Father's dose due at 2:00 PM", time:"5m ago" },
      { ic:"📄", color:"info", title:"New report uploaded", sub:"Thyroid profile for Mother", time:"2h ago" },
      { ic:"🤖", color:"warning", title:"New AI insight available", sub:"Blood sugar trend flagged for Father", time:"1d ago" },
      { ic:"🩺", color:"success", title:"Checkup reminder", sub:"Mother's annual screening is due", time:"2d ago" },
    ],

    activity: [
      { ic:"📤", title:"Ananya uploaded a blood test report for Rajesh", time:"Today, 9:42 AM" },
      { ic:"💊", title:"Sunita marked Calcium + D3 as taken", time:"Today, 9:05 AM" },
      { ic:"🤖", title:"AI flagged a new health insight for Rajesh", time:"Yesterday, 6:20 PM" },
      { ic:"🩺", title:"Doctor visit logged — Cardiology follow-up", time:"Jun 15, 4:10 PM" },
      { ic:"💉", title:"Vaccination record added for Aarav", time:"Jun 02, 11:30 AM" },
    ],

    healthScoreTrend:[68,70,69,73,75,74,77,79,80,82,81,84],

    waitlist:{ responses:54, waitlistGoal:150, waitlistCurrent:97, interns:5 }
  };

  const KEY = "jeevani_mvp_data_v1";

  function load(){
    try{
      const raw = localStorage.getItem(KEY);
      if(!raw) { save(DEFAULTS); return structuredCloneSafe(DEFAULTS); }
      return JSON.parse(raw);
    }catch(e){ return structuredCloneSafe(DEFAULTS); }
  }
  function save(data){ localStorage.setItem(KEY, JSON.stringify(data)); }
  function structuredCloneSafe(o){ return JSON.parse(JSON.stringify(o)); }
  function reset(){ save(DEFAULTS); }

  return { load, save, reset, DEFAULTS };
})();
