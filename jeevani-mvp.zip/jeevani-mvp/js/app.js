/* ==========================================================================
   JEEVANI — App Shell (sidebar / topbar / theme / toast / notifications)
   Injected into every internal page via #app-shell-root.
   ========================================================================== */

const NAV_ITEMS = [
  { href:"dashboard.html",   ic:"&#128202;", label:"Dashboard" },
  { href:"records.html",     ic:"&#128193;", label:"Records" },
  { href:"reminders.html",   ic:"&#128138;", label:"Reminders" },
  { href:"ai-insights.html", ic:"&#129302;", label:"AI Insights" },
  { href:"timeline.html",    ic:"&#128197;", label:"Timeline" },
  { href:"emergency.html",   ic:"&#128680;", label:"Emergency" },
  { href:"settings.html",    ic:"&#9881;&#65039;", label:"Settings" },
];

function currentPage(){
  return location.pathname.split("/").pop() || "dashboard.html";
}

function renderShell(pageTitle, pageSubtitle){
  const page = currentPage();
  const navHtml = NAV_ITEMS.map(item => `
    <a class="snav-item ${item.href===page?'active':''}" href="${item.href}">
      <span class="ic">${item.ic}</span><span>${item.label}</span>
    </a>`).join("");

  const data = JeevaniData.load();

  document.body.insertAdjacentHTML('afterbegin', `
  <div class="sidebar-backdrop" id="sidebarBackdrop"></div>
  <div class="app-shell">
    <aside class="sidebar" id="sidebar">
      <div class="sidebar-logo">
        <img src="assets/logo-horizontal.png" alt="Jeevani" style="height:30px;width:auto;object-fit:contain;object-position:left;clip-path:inset(0 70% 0 0);margin-right:-58px;" />
        <span style="font-family:var(--font-display);font-weight:700;font-size:17px;color:var(--accent);">Jeevani</span>
        <button class="sidebar-close" id="sidebarClose">&times;</button>
      </div>
      <nav class="sidebar-nav">
        <div class="nav-section-lbl">Family Hub</div>
        ${navHtml}
      </nav>
      <div class="sidebar-foot">
        <div class="theme-toggle">
          <span>&#127769; Dark mode</span>
          <div class="switch" id="themeSwitch"></div>
        </div>
      </div>
    </aside>

    <div class="main">
      <header class="topbar">
        <div class="topbar-left">
          <button class="menu-btn" id="menuBtn">&#9776;</button>
          <h1>${pageTitle}</h1>
        </div>
        <div class="topbar-right">
          <div class="dropdown">
            <button class="icon-btn" id="notifBtn">&#128276;<span class="dot"></span></button>
            <div class="dropdown-panel" id="notifPanel">
              <div class="dropdown-head"><span>Notifications</span><span class="lnk" style="color:var(--primary-dark);font-weight:600;font-size:12px;cursor:pointer;">Mark all read</span></div>
              ${data.notifications.map(n=>`
                <div class="notif-item">
                  <div class="notif-ic" style="background:var(--${n.color}-soft);">${n.ic}</div>
                  <div><div class="notif-title">${n.title}</div><div class="notif-sub">${n.sub} · ${n.time}</div></div>
                </div>`).join("")}
            </div>
          </div>
          <div class="dropdown">
            <div class="avatar-chip" id="avatarChip">
              <span class="av">AS</span>
              <span class="nm">${data.user.name.split(" ")[0]}</span>
            </div>
          </div>
        </div>
      </header>
      <main class="page-body" id="pageBody">
        ${pageSubtitle ? `<div class="page-head"><div><h2>${pageTitle}</h2><p>${pageSubtitle}</p></div><div id="pageHeadActions"></div></div>` : ""}
      </main>
    </div>
  </div>
  <div id="toast-host"></div>
  `);

  // wire interactions
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.getElementById('sidebarBackdrop');
  document.getElementById('menuBtn')?.addEventListener('click', ()=>{ sidebar.classList.add('open'); backdrop.classList.add('open'); });
  document.getElementById('sidebarClose')?.addEventListener('click', ()=>{ sidebar.classList.remove('open'); backdrop.classList.remove('open'); });
  backdrop.addEventListener('click', ()=>{ sidebar.classList.remove('open'); backdrop.classList.remove('open'); });

  const notifBtn = document.getElementById('notifBtn');
  const notifPanel = document.getElementById('notifPanel');
  notifBtn.addEventListener('click', (e)=>{ e.stopPropagation(); notifPanel.classList.toggle('open'); });
  document.addEventListener('click', ()=> notifPanel.classList.remove('open'));

  initTheme();
}

function initTheme(){
  const sw = document.getElementById('themeSwitch');
  const isDark = localStorage.getItem('jeevani_theme') === 'dark';
  if(isDark){ document.documentElement.setAttribute('data-theme','dark'); sw.classList.add('on'); }
  sw.addEventListener('click', ()=>{
    const nowDark = document.documentElement.getAttribute('data-theme') === 'dark';
    if(nowDark){ document.documentElement.removeAttribute('data-theme'); localStorage.setItem('jeevani_theme','light'); sw.classList.remove('on'); }
    else{ document.documentElement.setAttribute('data-theme','dark'); localStorage.setItem('jeevani_theme','dark'); sw.classList.add('on'); }
  });
}

// Apply persisted theme ASAP (before shell renders) to avoid flash
(function(){
  if(localStorage.getItem('jeevani_theme') === 'dark'){
    document.documentElement.setAttribute('data-theme','dark');
  }
})();

function toast(msg, icon){
  const host = document.getElementById('toast-host');
  if(!host) return;
  const el = document.createElement('div');
  el.className = 'toast';
  el.innerHTML = `<span>${icon||'&#9989;'}</span><span>${msg}</span>`;
  host.appendChild(el);
  setTimeout(()=>{ el.style.opacity='0'; el.style.transition='opacity .3s'; setTimeout(()=>el.remove(),300); }, 2600);
}

function pulseRingSVG(value, size=64, stroke=7, color){
  const r = (size-stroke)/2;
  const c = 2*Math.PI*r;
  const offset = c - (value/100)*c;
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
    <circle class="ring-bg" cx="${size/2}" cy="${size/2}" r="${r}" stroke-width="${stroke}"></circle>
    <circle class="ring-fg" cx="${size/2}" cy="${size/2}" r="${r}" stroke-width="${stroke}" stroke-dasharray="${c}" stroke-dashoffset="${offset}" ${color?`style="stroke:${color}"`:''}></circle>
  </svg>`;
}

function scoreColor(score){
  if(score>=85) return 'var(--primary)';
  if(score>=70) return 'var(--warning)';
  return 'var(--danger)';
}

function fmtDate(d){
  const dt = new Date(d);
  return dt.toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });
}

function initRevealOnScroll(){
  const els = document.querySelectorAll('.reveal');
  const io = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold:.12 });
  els.forEach(el=>io.observe(el));
}
